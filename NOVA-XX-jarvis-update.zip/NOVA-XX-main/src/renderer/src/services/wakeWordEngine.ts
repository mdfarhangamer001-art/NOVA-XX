/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * Wake Word Engine
 * ------------------------------------------------------------------
 * A lightweight, always-on background listener that watches for a
 * configurable wake phrase (e.g. "Hey IRIS") using the browser's
 * native SpeechRecognition API. When triggered, it hands control
 * back to the caller (IRISRoot) which activates the full
 * conversation-mode recognizer.
 *
 * This is intentionally decoupled from the main conversation
 * recognizer in IRISRoot.tsx: only one SpeechRecognition instance
 * should ever be active at a time, so IRISRoot is responsible for
 * starting/stopping this engine opposite to the connected state.
 */

export const DEFAULT_WAKE_PHRASES = ['hey iris', 'iris', 'wake up iris', 'yo iris']

const STORAGE_ENABLED_KEY = 'novax_wake_enabled'
const STORAGE_PHRASES_KEY = 'novax_wake_phrases'

export function isWakeWordEnabled(): boolean {
  const stored = localStorage.getItem(STORAGE_ENABLED_KEY)
  // Enabled by default so the hands-free experience works out of the box
  return stored === null ? true : stored === 'true'
}

export function setWakeWordEnabled(enabled: boolean): void {
  localStorage.setItem(STORAGE_ENABLED_KEY, String(enabled))
}

export function getWakePhrases(): string[] {
  const raw = localStorage.getItem(STORAGE_PHRASES_KEY)
  if (!raw) return DEFAULT_WAKE_PHRASES
  try {
    const parsed = JSON.parse(raw)
    if (Array.isArray(parsed) && parsed.length > 0) {
      return parsed.map((p) => String(p).toLowerCase().trim()).filter(Boolean)
    }
  } catch {
    // fall through to default
  }
  return DEFAULT_WAKE_PHRASES
}

export function setWakePhrases(phrases: string[]): void {
  const cleaned = phrases.map((p) => p.toLowerCase().trim()).filter(Boolean)
  localStorage.setItem(STORAGE_PHRASES_KEY, JSON.stringify(cleaned))
}

/** Strip punctuation and collapse whitespace for forgiving matching. */
function normalize(text: string): string {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, '')
    .replace(/\s+/g, ' ')
    .trim()
}

/** Returns true if any configured wake phrase appears inside the heard transcript. */
export function transcriptContainsWakePhrase(
  transcript: string,
  phrases: string[] = getWakePhrases()
): { matched: boolean; remainder: string } {
  const normalizedTranscript = normalize(transcript)
  for (const phrase of phrases) {
    const normalizedPhrase = normalize(phrase)
    if (!normalizedPhrase) continue
    const idx = normalizedTranscript.indexOf(normalizedPhrase)
    if (idx !== -1) {
      // Whatever the user said *after* the wake word, in case they said
      // "Hey IRIS, open Chrome" in a single breath.
      const remainder = normalizedTranscript.slice(idx + normalizedPhrase.length).trim()
      return { matched: true, remainder }
    }
  }
  return { matched: false, remainder: '' }
}

type WakeEngineCallbacks = {
  onWake: (spokenRemainder: string) => void
  onStatusChange?: (status: 'idle' | 'listening' | 'unsupported' | 'error') => void
}

let recognitionInstance: any = null
let isEngineActive = false
let restartTimer: ReturnType<typeof setTimeout> | null = null

export function isWakeEngineSupported(): boolean {
  return !!(window as any).SpeechRecognition || !!(window as any).webkitSpeechRecognition
}

/**
 * Starts the background wake-word listener. Safe to call repeatedly;
 * it will no-op if already running.
 */
export function startWakeWordEngine(lang: string, callbacks: WakeEngineCallbacks): void {
  if (isEngineActive) return

  const SpeechRecognitionCtor =
    (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition
  if (!SpeechRecognitionCtor) {
    console.warn('[NOVA-X Wake Engine] SpeechRecognition not supported in this environment.')
    callbacks.onStatusChange?.('unsupported')
    return
  }

  isEngineActive = true
  callbacks.onStatusChange?.('listening')

  const boot = (): void => {
    if (!isEngineActive) return

    const recognition = new SpeechRecognitionCtor()
    recognitionInstance = recognition
    recognition.continuous = true
    recognition.interimResults = false
    recognition.lang = lang

    recognition.onresult = (event: any): void => {
      const lastIndex = event.results.length - 1
      const transcript = event.results[lastIndex][0].transcript
      const { matched, remainder } = transcriptContainsWakePhrase(transcript)
      if (matched) {
        console.log('[NOVA-X Wake Engine] Wake phrase detected:', transcript)
        callbacks.onWake(remainder)
      }
    }

    recognition.onerror = (event: any): void => {
      // 'no-speech' and 'aborted' are expected/benign in a continuous loop
      if (event.error !== 'no-speech' && event.error !== 'aborted') {
        console.warn('[NOVA-X Wake Engine] Recognition error:', event.error)
        callbacks.onStatusChange?.('error')
      }
    }

    recognition.onend = (): void => {
      // Browsers silently stop continuous recognition after a while;
      // restart automatically as long as the engine should be running.
      if (isEngineActive) {
        restartTimer = setTimeout(() => {
          try {
            recognition.start()
          } catch {
            // If start() fails because it's already running, rebuild fresh
            boot()
          }
        }, 300)
      }
    }

    try {
      recognition.start()
    } catch (err) {
      console.error('[NOVA-X Wake Engine] Failed to start recognition:', err)
    }
  }

  boot()
}

/** Stops the background wake-word listener. */
export function stopWakeWordEngine(): void {
  isEngineActive = false
  if (restartTimer) {
    clearTimeout(restartTimer)
    restartTimer = null
  }
  if (recognitionInstance) {
    try {
      recognitionInstance.onend = null
      recognitionInstance.onresult = null
      recognitionInstance.onerror = null
      recognitionInstance.stop()
    } catch {
      // ignore
    }
    recognitionInstance = null
  }
}
