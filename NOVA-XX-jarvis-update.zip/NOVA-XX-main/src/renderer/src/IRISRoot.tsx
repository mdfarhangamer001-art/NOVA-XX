import { useState, useEffect, useRef } from 'react'
import IRIS from './UI/IRIS'
import TitleBar from './components/Titlebar'
import {
  startWakeWordEngine,
  stopWakeWordEngine,
  isWakeWordEnabled,
  isWakeEngineSupported
} from './services/wakeWordEngine'

export type VisionMode = 'camera' | 'screen' | 'none'

const IndexRoot = (): JSX.Element => {
  const [isConnected, setIsConnected] = useState(false)
  const [isSpeaking, setIsSpeaking] = useState(false)
  const [isMuted, setIsMuted] = useState(false)

  // Expose speaking state setter globally to link speech engine with Three.js rendering
  useEffect(() => {
    if (typeof window !== 'undefined') {
      // @ts-ignore - Expose global setter for speaking animation state linkage
      window.setIsSpeaking = (val: boolean): void => {
        setIsSpeaking(val)
      }
    }
    return () => {
      if (typeof window !== 'undefined') {
        /* eslint-disable-next-line @typescript-eslint/no-dynamic-delete */
        delete (window as Record<string, unknown>).setIsSpeaking
      }
    }
  }, [])

  // Tracks whether the current session was started by the wake word
  // (as opposed to the manual mic button), so we know whether to
  // auto-sleep after a period of silence.
  const wokenByVoiceRef = useRef(false)
  const idleSleepTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  const clearIdleSleepTimer = (): void => {
    if (idleSleepTimerRef.current) {
      clearTimeout(idleSleepTimerRef.current)
      idleSleepTimerRef.current = null
    }
  }

  const toggleConnection = (): void => {
    if (isConnected) {
      wokenByVoiceRef.current = false
      clearIdleSleepTimer()
      setIsConnected(false)
      setIsMuted(false)
    } else {
      wokenByVoiceRef.current = false
      setIsConnected(true)
      setIsSpeaking(false) // Wait for user speech first
    }
  }

  const handleMicToggle = (): void => {
    const nextMutedState = !isMuted
    setIsMuted(nextMutedState)
  }

  const [activeLang, setActiveLang] = useState(() => {
    return (window as any).selectedLanguage || localStorage.getItem('novax_lang') || 'en-US'
  })

  useEffect(() => {
    const handleLangChange = (e: any) => {
      setActiveLang(e.detail || 'en-US')
    }
    window.addEventListener('novax_lang_changed', handleLangChange)
    return () => {
      window.removeEventListener('novax_lang_changed', handleLangChange)
    }
  }, [])

  // Background Wake Word Listener
  // Runs only while the assistant is NOT already connected, so it never
  // fights with the main conversation recognizer below for the microphone.
  useEffect(() => {
    if (isConnected) {
      stopWakeWordEngine()
      return
    }

    if (!isWakeWordEnabled() || !isWakeEngineSupported()) {
      return
    }

    startWakeWordEngine(activeLang, {
      onWake: (spokenRemainder) => {
        console.log('[NOVA-X] Woken by voice. Activating conversation core.')
        wokenByVoiceRef.current = true
        setIsMuted(false)
        setIsConnected(true)
        setIsSpeaking(false)

        // Bring the window to the foreground even if it was minimized
        // or sitting in the background when the wake word was spoken.
        if ((window as any).electron?.ipcRenderer) {
          ;(window as any).electron.ipcRenderer.send('focus-window')
        }

        // Greet the operator, and if they packed a command into the same
        // breath ("Hey IRIS, open Chrome"), run it immediately.
        setTimeout(() => {
          if ((window as any).speakText) {
            ;(window as any).speakText(spokenRemainder ? 'On it, Boss.' : 'Yes, Boss?')
          }
          if (spokenRemainder && (window as any).triggerVoiceCommand) {
            ;(window as any).triggerVoiceCommand(spokenRemainder)
          }
        }, 150)
      }
    })

    return () => {
      stopWakeWordEngine()
    }
  }, [isConnected, activeLang])

  // Auto-sleep: if a session was started hands-free by the wake word and
  // the operator goes quiet for a while, drop back to background
  // listening instead of keeping the mic hot indefinitely.
  useEffect(() => {
    if (!isConnected || !wokenByVoiceRef.current) {
      clearIdleSleepTimer()
      return
    }

    clearIdleSleepTimer()
    idleSleepTimerRef.current = setTimeout(() => {
      if (wokenByVoiceRef.current) {
        console.log('[NOVA-X] No activity detected. Returning to background listening.')
        wokenByVoiceRef.current = false
        setIsConnected(false)
        setIsMuted(false)
      }
    }, 45000)

    return clearIdleSleepTimer
    // Restart the idle timer every time the assistant finishes speaking
    // or the mic hears something new, since those are our best signals
    // of continued activity.
  }, [isConnected, isSpeaking])

  // Real-time Voice Recognition Loop
  useEffect(() => {
    // @ts-ignore - Check for browser speech recognition variants
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
    if (!SpeechRecognition) {
      console.warn('[NOVA-X] Speech Recognition API not supported in this environment.')
      return
    }

    /* eslint-disable-next-line @typescript-eslint/no-explicit-any */
    let recognition: any = null
    const shouldBeRunning = isConnected && !isMuted && !isSpeaking

    if (shouldBeRunning) {
      console.log(`[NOVA-X] Activating Voice Recognition Core for Language: ${activeLang}...`)
      recognition = new SpeechRecognition()
      recognition.continuous = true
      recognition.interimResults = false
      recognition.lang = activeLang

      recognition.onstart = (): void => {
        console.log('[NOVA-X] Microphone listening active.')
      }

      /* eslint-disable-next-line @typescript-eslint/no-explicit-any */
      recognition.onresult = (event: any): void => {
        const lastResultIndex = event.results.length - 1
        const transcript = event.results[lastResultIndex][0].transcript
        console.log('[NOVA-X] Audio recognized:', transcript)

        if (transcript && transcript.trim().length > 0) {
          // Send recognized vocal transcript into the Conversation Core
          // @ts-ignore - Invoke global trigger handler
          if (window.triggerVoiceCommand) {
            // @ts-ignore - Invoke global trigger handler
            window.triggerVoiceCommand(transcript)
          }
        }
      }

      /* eslint-disable-next-line @typescript-eslint/no-explicit-any */
      recognition.onerror = (event: any): void => {
        console.error('[NOVA-X] Speech Recognition error:', event.error)
      }

      recognition.onend = (): void => {
        console.log('[NOVA-X] Microphone listener closed.')
        // Auto-restart if we should still be running and not closed manually
        if (isConnected && !isMuted && !isSpeaking) {
          try {
            recognition.start()
          } catch (err) {
            console.error('[NOVA-X] Failed restarting mic lock:', err)
          }
        }
      }

      try {
        recognition.start()
      } catch (err) {
        console.error('[NOVA-X] Error starting recognition thread:', err)
      }
    }

    return () => {
      if (recognition) {
        console.log('[NOVA-X] Deactivating recognition core.')
        recognition.onend = null // avoid loop
        try {
          recognition.stop()
        } catch (_e) {
          // Silent safe error catching
        }
      }
    }
  }, [isConnected, isMuted, isSpeaking, activeLang])

  return (
    <div className="flex flex-col h-screen w-screen bg-black overflow-hidden relative border border-emerald-500/20 rounded-xl">
      <TitleBar />
      <div className="flex-1 relative">
        <IRIS
          isConnected={isConnected}
          toggleConnection={toggleConnection}
          isSpeaking={isSpeaking}
          isMuted={isMuted}
          handleMicToggle={handleMicToggle}
        />
      </div>
    </div>
  )
}

export default IndexRoot