import { useState, useEffect, useRef, useCallback } from 'react'
import {
  RiImage2Line,
  RiDeleteBinLine,
  RiFolderOpenLine,
  RiCloseLine,
  RiDatabase2Line,
  RiFileWarningLine,
  RiArrowLeftSLine,
  RiArrowRightSLine,
  RiDownloadLine,
  RiVideoLine,
  RiPlayCircleLine,
  RiLayoutGridFill
} from 'react-icons/ri'
import { motion, AnimatePresence } from 'framer-motion'

interface MediaFile {
  filename: string
  displayName: string
  path: string
  url: string
  createdAt: Date
  type: 'image' | 'video'
}

const GalleryView = () => {
  const [allMedia, setAllMedia] = useState<MediaFile[]>([])
  const [visibleMedia, setVisibleMedia] = useState<MediaFile[]>([])
  const [selectedMedia, setSelectedMedia] = useState<MediaFile | null>(null)

  const [direction, setDirection] = useState(0)
  const [page, setPage] = useState(1)
  const ITEMS_PER_PAGE = 12
  const observer = useRef<IntersectionObserver | null>(null)

  const lastMediaRef = useCallback(
    (node: HTMLDivElement) => {
      if (observer.current) observer.current.disconnect()
      observer.current = new IntersectionObserver((entries) => {
        if (entries[0].isIntersecting && visibleMedia.length < allMedia.length) {
          setPage((prev) => prev + 1)
        }
      })
      if (node) observer.current.observe(node)
    },
    [visibleMedia.length, allMedia.length]
  )

  const fetchGallery = async () => {
    try {
      const data = await window.electron.ipcRenderer.invoke('get-gallery')
      if (Array.isArray(data)) {
        const typedData = data
          .map((item: any) => ({
            ...item,
            type: item.filename.toLowerCase().endsWith('.mp4') ? 'video' : 'image'
          }))
          .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())

        setAllMedia(typedData)
      }
    } catch (e) {
      console.error('Failed to load media files.')
    }
  }

  useEffect(() => {
    fetchGallery()
    const interval = setInterval(fetchGallery, 5000)
    return () => clearInterval(interval)
  }, [])

  useEffect(() => {
    const endIndex = page * ITEMS_PER_PAGE
    setVisibleMedia(allMedia.slice(0, endIndex))
  }, [page, allMedia])

  const deleteMedia = async (filename: string, e?: React.MouseEvent) => {
    e?.stopPropagation()
    await window.electron.ipcRenderer.invoke('delete-image', filename)

    if (selectedMedia) {
      const currentIndex = allMedia.findIndex((media) => media.filename === selectedMedia.filename)
      const nextMedia = allMedia[currentIndex + 1] || allMedia[currentIndex - 1]
      setSelectedMedia(nextMedia || null)
    }
    fetchGallery()
  }

  const openLocation = async (path: string, e?: React.MouseEvent) => {
    e?.stopPropagation()
    await window.electron.ipcRenderer.invoke('open-image-location', path)
  }

  const saveCopy = async (path: string, e?: React.MouseEvent) => {
    e?.stopPropagation()
    await window.electron.ipcRenderer.invoke('save-image-external', path)
  }

  const navigateMedia = useCallback(
    (newDirection: number) => {
      if (!selectedMedia || allMedia.length === 0) return
      setDirection(newDirection)

      const currentIndex = allMedia.findIndex((media) => media.filename === selectedMedia.filename)
      if (currentIndex === -1) return

      let newIndex = currentIndex + newDirection
      if (newIndex >= allMedia.length) newIndex = 0
      if (newIndex < 0) newIndex = allMedia.length - 1

      setSelectedMedia(allMedia[newIndex])
    },
    [selectedMedia, allMedia]
  )

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!selectedMedia) return
      if (e.key === 'ArrowRight') navigateMedia(1)
      if (e.key === 'ArrowLeft') navigateMedia(-1)
      if (e.key === 'Escape') setSelectedMedia(null)
    }
    window.addEventListener('keydown', handleKeyDown)
    return () => window.removeEventListener('keydown', handleKeyDown)
  }, [selectedMedia, navigateMedia])

  const variants = {
    enter: (dir: number) => ({
      x: dir > 0 ? 800 : -800,
      opacity: 0,
      scale: 0.9,
      filter: 'blur(10px)'
    }),
    center: { zIndex: 1, x: 0, opacity: 1, scale: 1, filter: 'blur(0px)' },
    exit: (dir: number) => ({
      zIndex: 0,
      x: dir < 0 ? 800 : -800,
      opacity: 0,
      scale: 0.9,
      filter: 'blur(10px)'
    })
  }

  return (
    <div className="flex-1 bg-neutral-950 h-full p-8 md:p-10 animate-in fade-in duration-500 flex flex-col overflow-hidden selection:bg-emerald-500/30 text-white font-sans">
      <div className="flex items-end justify-between pb-6 border-b border-white/5 mb-8 shrink-0">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-neutral-900 rounded-2xl border border-neutral-800 shadow-md">
            <RiLayoutGridFill className="text-emerald-500" size={28} />
          </div>
          <div>
            <h2 className="text-xl font-bold tracking-wider text-white uppercase flex items-center gap-2">
              Media Vault
            </h2>
            <p className="text-xs text-neutral-500 mt-1 uppercase tracking-widest">
              Local Device Storage
            </p>
          </div>
        </div>

        <div className="text-xs font-bold tracking-widest text-emerald-500 bg-neutral-900 px-4 py-2 rounded-lg border border-neutral-800 shadow-sm flex items-center gap-2">
          <RiDatabase2Line size={14} /> {allMedia.length} FILES
        </div>
      </div>

      <div className="flex-1 overflow-y-auto custom-scrollbar pr-2 min-h-0">
        {allMedia.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-neutral-600 gap-5">
            <div className="w-24 h-24 rounded-full bg-neutral-900 flex items-center justify-center border border-neutral-800 shadow-inner">
              <RiImage2Line size={40} className="opacity-20" />
            </div>
            <p className="text-sm font-bold tracking-widest opacity-40 uppercase">No Media Found</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6 pb-12 auto-rows-max">
            {visibleMedia.map((media, index) => {
              const isLast = index === visibleMedia.length - 1
              const isVideo = media.type === 'video'

              return (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05, duration: 0.4 }}
                  key={`${media.filename}-${index}`}
                  ref={isLast ? lastMediaRef : null}
                  onClick={() => {
                    setDirection(0)
                    setSelectedMedia(media)
                  }}
                  className="group relative aspect-square md:aspect-4/5 bg-neutral-900 rounded-2xl border border-white/5 overflow-hidden hover:border-emerald-500/50 hover:shadow-lg transition-all duration-300 cursor-pointer"
                >
                  {isVideo ? (
                    <video
                      src={media.url}
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105 opacity-80 group-hover:opacity-100"
                      preload="metadata"
                      muted
                      playsInline
                      loop
                      onMouseEnter={(e) => {
                        e.currentTarget.play().catch(() => {})
                      }}
                      onMouseLeave={(e) => {
                        e.currentTarget.pause()
                        e.currentTarget.currentTime = 0
                      }}
                    >
                      <source src={media.url} type="video/mp4" />
                    </video>
                  ) : (
                    <img
                      src={media.url}
                      alt={media.displayName}
                      loading="lazy"
                      onError={(e) => {
                        e.currentTarget.style.display = 'none'
                        e.currentTarget.nextElementSibling?.classList.remove('hidden')
                      }}
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105 opacity-80 group-hover:opacity-100"
                    />
                  )}

                  <div className="hidden absolute inset-0 items-center justify-center flex-col gap-3 bg-neutral-950">
                    <RiFileWarningLine className="text-red-500/40" size={32} />
                    <span className="text-[10px] font-bold tracking-widest text-neutral-500">
                      CANNOT LOAD
                    </span>
                  </div>

                  {isVideo && (
                    <div className="absolute top-3 left-3 bg-black/70 backdrop-blur-md px-2.5 py-1 rounded-md border border-white/10 flex items-center gap-1.5 z-10 pointer-events-none">
                      <RiVideoLine size={12} className="text-emerald-400" />
                      <span className="text-[10px] font-bold tracking-widest text-white">
                        VIDEO
                      </span>
                    </div>
                  )}

                  <div className="absolute inset-0 bg-linear-to-t from-black via-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-all duration-300 flex flex-col justify-end p-4 pointer-events-none">
                    <div className="mb-3">
                      <p className="text-xs text-white font-bold mb-1 truncate">
                        {media.displayName}
                      </p>
                      <p className="text-[10px] text-neutral-400">
                        {new Date(media.createdAt).toLocaleString()}
                      </p>
                    </div>

                    <div className="flex gap-2 justify-end pointer-events-auto">
                      <button
                        onClick={(e) => openLocation(media.path, e)}
                        className="p-2 bg-neutral-800 text-white rounded hover:bg-emerald-500 hover:text-black transition-colors"
                        title="Locate File"
                      >
                        <RiFolderOpenLine size={16} />
                      </button>
                      <button
                        onClick={(e) => deleteMedia(media.filename, e)}
                        className="p-2 bg-neutral-800 text-white rounded hover:bg-red-500 hover:text-white transition-colors"
                        title="Delete File"
                      >
                        <RiDeleteBinLine size={16} />
                      </button>
                    </div>
                  </div>

                  {isVideo && (
                    <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity">
                      <RiPlayCircleLine size={48} className="text-white drop-shadow-md" />
                    </div>
                  )}
                </motion.div>
              )
            })}
          </div>
        )}
      </div>

      <AnimatePresence>
        {selectedMedia && (
          <motion.div
            initial={{ opacity: 0, backdropFilter: 'blur(0px)' }}
            animate={{ opacity: 1, backdropFilter: 'blur(20px)' }}
            exit={{ opacity: 0, backdropFilter: 'blur(0px)' }}
            transition={{ duration: 0.3 }}
            className="fixed inset-0 z-9999 bg-black/90 flex items-center justify-center"
          >
            <div className="absolute top-0 left-0 right-0 p-6 flex justify-between items-center z-50">
              <div className="text-left px-4 py-2 bg-neutral-900/60 backdrop-blur-md rounded-lg border border-white/10">
                <h3 className="text-base font-bold text-white tracking-wide flex items-center gap-2">
                  {selectedMedia.type === 'video' ? (
                    <RiVideoLine className="text-emerald-500" />
                  ) : (
                    <RiImage2Line className="text-emerald-500" />
                  )}
                  {selectedMedia.displayName}
                </h3>
                <p className="text-[11px] text-neutral-400 mt-1">
                  {new Date(selectedMedia.createdAt).toLocaleString()}
                </p>
              </div>

              <button
                onClick={() => setSelectedMedia(null)}
                className="cursor-pointer p-3 bg-neutral-900 hover:bg-red-500 hover:text-white rounded-full text-neutral-400 transition-colors border border-white/10"
              >
                <RiCloseLine size={24} />
              </button>
            </div>

            <div
              className="absolute left-0 top-0 bottom-0 w-32 z-40 flex items-center justify-start pl-6 group cursor-pointer hover:bg-linear-to-r from-black/40 to-transparent"
              onClick={() => navigateMedia(-1)}
            >
              <div className="p-4 bg-neutral-900 group-hover:bg-white text-white group-hover:text-black rounded-full transition-colors border border-white/10">
                <RiArrowLeftSLine size={28} />
              </div>
            </div>

            <div
              className="absolute right-0 top-0 bottom-0 w-32 z-40 flex items-center justify-end pr-6 group cursor-pointer hover:bg-linear-to-l from-black/40 to-transparent"
              onClick={() => navigateMedia(1)}
            >
              <div className="p-4 bg-neutral-900 group-hover:bg-white text-white group-hover:text-black rounded-full transition-colors border border-white/10">
                <RiArrowRightSLine size={28} />
              </div>
            </div>

            <div className="relative w-full h-full flex flex-col items-center justify-center pt-20 pb-28 px-32">
              <AnimatePresence initial={false} custom={direction} mode="wait">
                <motion.div
                  key={selectedMedia.filename}
                  custom={direction}
                  variants={variants}
                  initial="enter"
                  animate="center"
                  exit="exit"
                  transition={{ type: 'spring', stiffness: 250, damping: 30 }}
                  className="relative w-full h-full flex items-center justify-center"
                >
                  {selectedMedia.type === 'video' ? (
                    <video
                      src={selectedMedia.url}
                      controls
                      autoPlay
                      className="max-w-full max-h-full rounded-lg shadow-2xl border border-white/10 bg-black outline-none"
                    />
                  ) : (
                    <img
                      src={selectedMedia.url}
                      className="max-w-full max-h-full rounded-lg shadow-2xl border border-white/10 object-contain bg-black"
                    />
                  )}
                </motion.div>
              </AnimatePresence>
            </div>

            <div className="absolute bottom-8 z-50 flex gap-3 p-2 bg-neutral-900/80 backdrop-blur-md border border-white/10 rounded-xl">
              <button
                onClick={(e) => openLocation(selectedMedia.path, e)}
                className="cursor-pointer flex items-center gap-2 px-5 py-2.5 hover:bg-white text-white hover:text-black rounded-lg text-xs font-bold tracking-wide transition-colors"
              >
                <RiFolderOpenLine size={16} /> Locate
              </button>
              <button
                onClick={(e) => saveCopy(selectedMedia.path, e)}
                className="cursor-pointer flex items-center gap-2 px-5 py-2.5 bg-emerald-500/20 hover:bg-emerald-500 text-emerald-400 hover:text-black rounded-lg text-xs font-bold tracking-wide transition-colors border border-emerald-500/20"
              >
                <RiDownloadLine size={16} /> Export
              </button>
              <button
                onClick={(e) => deleteMedia(selectedMedia.filename, e)}
                className="cursor-pointer flex items-center gap-2 px-5 py-2.5 bg-red-500/10 hover:bg-red-500 text-red-500 hover:text-white rounded-lg text-xs font-bold tracking-wide transition-colors border border-red-500/20"
              >
                <RiDeleteBinLine size={16} /> Delete
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

export default GalleryView
